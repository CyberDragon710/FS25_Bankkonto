Bankkonto = {}

print("[FS25_Bankkonto] Bankkonto.lua geladen")